﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Application.Interfaces
{
    public interface ICache
    {
        Task<T> GetAsyc<T>(string key);

        Task SetAsyc<T>(string key, T value);
    }
}
