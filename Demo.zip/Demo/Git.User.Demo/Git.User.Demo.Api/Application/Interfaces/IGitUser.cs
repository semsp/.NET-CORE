﻿using Git.User.Demo.Api.Application.ViewModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Application.Interfaces
{
    public interface IGitUser
    {
        Task<IList<UserViewModel>> GetGitUsersAsync(IList<string> userNames);
    }
}
