﻿using Git.User.Demo.Api.Application.Interfaces;
using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Text.Json;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Application.Services
{
    public class CacheManager : ICache
    {
        private readonly IDistributedCache _cache;

        public CacheManager(IDistributedCache cache)
        {
            _cache = cache;
        }

        public async Task<T> GetAsyc<T>(string key)
        {
            try
            {
                var data = await _cache.GetStringAsync(key);
                if (data == null)
                    return default;

                T result = JsonSerializer.Deserialize<T>(data);
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return default;
            }
        }

        public async Task SetAsyc<T>(string key, T value)
        {
            await _cache.SetStringAsync(key, JsonSerializer.Serialize(value), new DistributedCacheEntryOptions()
            {
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(2)
            });
        }
    }
}
