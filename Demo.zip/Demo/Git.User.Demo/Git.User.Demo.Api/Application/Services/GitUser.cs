﻿using Git.User.Demo.Api.Application.Interfaces;
using Git.User.Demo.Api.Application.ViewModel;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Application.Services
{
    public class GitUser : IGitUser
    {
        readonly HttpClient _httpClient;
        private readonly ICache _cache;
        private readonly ILogger<GitUser> _logger;

        public GitUser(IHttpClientFactory httpClientFactory,
            ICache cache,
            ILogger<GitUser> logger)
        {
            _httpClient = httpClientFactory.CreateClient();
            _httpClient.BaseAddress = new Uri("https://api.github.com");
            _httpClient.DefaultRequestHeaders.Add("Accept", "application/vnd.github.v3+json");
            _httpClient.DefaultRequestHeaders.Add("User-Agent", "Demo Application");
            _cache = cache;
            _logger = logger;
        }

        public async Task<IList<UserViewModel>> GetGitUsersAsync(IList<string> userNames)
        {
            List<UserViewModel> userList = new List<UserViewModel>();
            foreach (var userName in userNames)
            {
                var cachedUser = await _cache.GetAsyc<UserViewModel>(userName);
                if (null == cachedUser)
                {
                    var model = await GetGitUserInfo(userName);
                    if (model != null)
                    {
                        _logger.LogInformation($"----- User details for name '{userName}' fetched from Git.");
                        userList.Add(model);
                        await _cache.SetAsyc(userName, model);
                    }
                }
                else
                {
                    _logger.LogInformation($"----- User details for name '{userName}' fetched from Cache.");
                    userList.Add(cachedUser);
                }
            }

            return userList.OrderBy(p => p.Name).ToList();
        }

        private async Task<UserViewModel> GetGitUserInfo(string userName)
        {
            var response = await _httpClient.GetAsync($"/users/{userName}");

            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var content = await response.Content.ReadAsStringAsync();
                UserViewModel model = System.Text.Json.JsonSerializer.Deserialize<UserViewModel>(content);
                return model;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
            {
                _logger.LogError($"There is no user exist with name: {userName}.");
                return default;
            }
            else
            {
                string errorContent = await response.Content.ReadAsStringAsync();
                _logger.LogError($"Error while fetching user details from Git. Status: {response.StatusCode}, Error: {errorContent}");
                return default;
            }
        }
    }
}
