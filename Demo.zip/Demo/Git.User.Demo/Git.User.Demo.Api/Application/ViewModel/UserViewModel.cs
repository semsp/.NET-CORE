﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Application.ViewModel
{
    public class UserViewModel
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("login")]
        public string Login { get; set; }

        [JsonPropertyName("company")]
        public string Company { get; set; }

        [JsonPropertyName("followers")]
        public int Followers { get; set; }

        [JsonPropertyName("public_repos")]
        public int Repositories { get; set; }

        public int AverageFollowers
        {
            get
            {
                if (Repositories > 0)
                {
                    return Followers / Repositories;
                }
                else
                    return 0;
            }
        }
    }
}
