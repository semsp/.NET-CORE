﻿using Git.User.Demo.Api.Application.Interfaces;
using Git.User.Demo.Api.Application.ViewModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace Git.User.Demo.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly ILogger<UserController> _logger;

        public UserController(ILogger<UserController> logger)
        {
            _logger = logger;
        }

        [ProducesResponseType(typeof(List<UserViewModel>), (int)HttpStatusCode.OK)]
        [HttpPost("Retrieve")]
        public async Task<IActionResult> Retrieve([FromBody] IList<string> userNames,
            [FromServices] IGitUser gitUser)
        {
            if (userNames is null || userNames.Count == 0)
            {
                _logger.LogError($"Input parameter {nameof(userNames)} is null or empty.");
                return BadRequest($"{nameof(userNames)} must not be null or empty.");
            }

            var users = await gitUser.GetGitUsersAsync(userNames);

            return Ok(users);
        }
    }
}
