using Git.User.Demo.Api.Application.Interfaces;
using Git.User.Demo.Api.Application.Services;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Xunit;

namespace Git.User.Demo.Tests
{
    public class CacheManager_UnitTests
    {

        public CacheManager_UnitTests()
        {
        }


        [Fact]
        public void SetValue_GetValue_GiveExpectedResult()
        {
            // Arrange
            string expetced = "TestVal";
            var opts = Options.Create(new MemoryDistributedCacheOptions());
            IDistributedCache cache = new MemoryDistributedCache(opts);
            ICache cacheManager = new CacheManager(cache);
            cacheManager.SetAsyc("TestKey", expetced);

            // Execute
            string value = cacheManager.GetAsyc<string>("TestKey").Result;

            //Assert
            Assert.Equal(expetced, value);
        }
    }
}
