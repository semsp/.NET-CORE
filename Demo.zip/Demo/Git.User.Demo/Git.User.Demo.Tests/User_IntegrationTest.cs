﻿using Git.User.Demo.Api;
using Git.User.Demo.Tests.Fixture;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Git.User.Demo.Tests
{
    public class User_IntegrationTest : IClassFixture<TestFixture<Startup>>
    {
        private HttpClient _client;

        public User_IntegrationTest(TestFixture<Startup> fixture)
        {
            _client = fixture.Client;
        }
        [Fact]
        public async Task GetUsersFromGit_GiveExpectedResult()
        {
            // Arrange
            var requestedUsers = new List<string>() { "mislav" };

            // Act
            var response = await _client.PostAsync("/api/User/Retrieve", new StringContent(System.Text.Json.JsonSerializer.Serialize(requestedUsers), Encoding.Default, "application/json"));
            var strUsers = await response.Content.ReadAsStringAsync();
            var userList = System.Text.Json.JsonSerializer.Deserialize<List<Api.Application.ViewModel.UserViewModel>>(strUsers);
            var firstUser = userList.First();

            // Assert
            Assert.Equal("rafaelfgx", firstUser.Login);

        }
    }
}