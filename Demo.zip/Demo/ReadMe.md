# Git User list Demo Application
## Application should fetch the users from Github for given list of usernames and cache them for 2 minutes.

## Prerequisite

- Visual Studio 2019
- C# 8+
- Dotnet 5 sdk


## Installation

1. Unzip folder and open .sln file in visual studio 2019
2. Make sure *Git.User.Demo.Api* is the startup project
3. Run the application can you can see swagger UI.
4. Or, you can run *http://localhost:5002/swagger/index.html*


